puncs = [',','.',':','?','!','"', '-', '，', '。', '：', '？', '！', '“', '”', '—']
test = ''.join([_.strip() for _ in open('test.txt','r').readlines()])
refer = ''.join([_.strip() for _ in open('refer.txt','r').readlines()])
file_out = open('output.txt','w')
for punc in puncs:
    test = test.replace(punc, '')
    refer = refer.replace(punc, '')
bag_result = []
for i in range(2,17):
    bag_test= set([test[_:_+i] for _ in range(len(test)-i-1)])
    bag_refer= set([refer[_:_+i] for _ in range(len(refer)-i-1)])
    bag_result = bag_test.intersection(bag_refer)
    file_out.write(str(i)+'\n')
    for element in bag_result:
        file_out.write(element+'\n')
    print('%i:%i'%(i, len(bag_result)))  

print(len(test))
print(len(refer))